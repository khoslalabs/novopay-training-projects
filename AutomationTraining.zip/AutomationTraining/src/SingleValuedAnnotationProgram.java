/**
 * @author bsoundar
 *
 */
public class SingleValuedAnnotationProgram extends BaseAnnotationProgram {

	public SingleValuedAnnotationProgram() {
		
	}

	@SuppressWarnings("unused")
	public static void main(String[] args) {

		String value = "";
		
		String abc = "Alphabet";
		
		int index = 2;
		
		int count = 10;
	}

}
