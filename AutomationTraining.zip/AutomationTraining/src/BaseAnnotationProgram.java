
/**
 * @author bsoundar
 *
 */
public class BaseAnnotationProgram {

	public BaseAnnotationProgram() {
		
	}
	
	public void printStringValue(String value) {
		System.out.println("BaseAnnotation - value : " + value);
	}

}
