package in.novopay.Training;

import org.testng.annotations.Test;

public class TestScenario {

	@Test
    public void testApp()
    {
        System.out.println("Execution");
    }
}
